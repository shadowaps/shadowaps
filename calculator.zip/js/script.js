let button = document.querySelectorAll('#buttons [type=button]');

button.forEach(element => element.addEventListener('click', getValue));

function getValue() {
  if ( Number.isInteger(+this.value) ) {
      alert('Я НОМЕР');
  } else if (this.value = '+') {
      alert('Я ПЛЮС');
  } else if (this.value = '-') {
      alert('Я МИНУС');
  }  else if (this.value = '*') {
      alert('Я УМНОЖЕНИЕ'); 
  }  else if (this.value = '/') {
      alert('Я ДЕЛЕНИЕ');
  } else {
      alert('ИДИ НА ХУЙ');
  }
}


/* let a = +prompt('Число1');
let operator = prompt('Оператор');
let b = +prompt('Число2');

const showEquals = (a, b, operator) => {
  switch (operator) {
    case '+':
      alert(a + b);
      break;
    case '-':
      alert(a - b);
      break;
    case '*':
      alert(a * b);
      break;
    case '/':
      alert(a / b); 
      break;  
  }
}

showEquals(a, b, operator); */


